// JavaScript to toggle between login and signup forms
document.addEventListener("DOMContentLoaded", function() {
    const loginBox = document.getElementById("loginBox");
    const signupBox = document.getElementById("signupBox");
    const loginLink = document.getElementById("loginLink");
    const signupLink = document.getElementById("signupLink");

    // Initially hide the signup box
    signupBox.style.display = "none";

    // Toggle to signup form
    signupLink.addEventListener("click", function(event) {
        event.preventDefault();
        loginBox.style.display = "none";
        signupBox.style.display = "block";
    });

    // Toggle to login form
    loginLink.addEventListener("click", function(event) {
        event.preventDefault();
        loginBox.style.display = "block";
        signupBox.style.display = "none";
    });
});
